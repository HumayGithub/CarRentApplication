﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace carrent.Models
{
    public class MainPageCarModel
    {
        public Car car { get; set; }
        public string marka { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace carrent.Models
{
    public class Model
    {
        public int id { get; set; }
        public string name { get; set; }
        public int Markaid { get; set; }
        public virtual Marka marka { get; set; }
    }
}
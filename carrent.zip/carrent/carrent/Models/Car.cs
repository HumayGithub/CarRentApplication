﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace carrent.Models
{
    public class Car
    {
        public int id { get; set; }
        [Required]
        [Range(2000, 2018, ErrorMessage = "Please enter from 2000-2018")]
               public int year { get; set; }
        [Required]
        public double price { get; set; }
        [Required]
        public string color { get; set; }
        [Required]
        public double distance { get; set; }
        public string imgUrl { get; set; }
        [Required]
        public int modelid { get; set; }
        public virtual Model model { get; set; }
    }
}
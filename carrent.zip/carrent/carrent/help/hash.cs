﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace carrent.help
{
    public static class hash
    {
        public static string hash1(string data)
        {
            var byteData = Encoding.ASCII.GetBytes(data);
            var sh = new SHA1CryptoServiceProvider();
            var byteHash = sh.ComputeHash(byteData);
            var result = "";
            foreach (var t in byteHash)
            {
                result += t.ToString("x2");
            }
            return result;
        }
    } 
}
﻿using carrent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace carrent.help
{
    public class CstAuthorize : AuthorizeAttribute
    {
        Model1 db = new Model1();





        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if ((string)httpContext.Session["auth"] != "true")
            {
                return false;
            }


            else
            {
                var id = (int)httpContext.Session["userid"];


                var find = db.Users.Find(id);
                if (find.isadmin == true)
                {
                    return true;
                }


                else
                {
                    return false;
                }

               


            }
        }
    }
}
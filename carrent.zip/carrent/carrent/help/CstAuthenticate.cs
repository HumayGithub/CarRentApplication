﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace carrent.help
{
    public class CstAuthenticate: AuthorizeAttribute
    {
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            
            return (string)httpContext.Session["auth"] == "true";
        }
    }
}
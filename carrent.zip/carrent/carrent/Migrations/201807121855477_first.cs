namespace carrent.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class first : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cars",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        year = c.Int(nullable: false),
                        price = c.Double(nullable: false),
                        color = c.String(),
                        distance = c.Double(nullable: false),
                        Markaid = c.Int(nullable: false),
                        model = c.String(),
                    })
                .PrimaryKey(t => t.id)
                .ForeignKey("dbo.Markas", t => t.Markaid, cascadeDelete: true)
                .Index(t => t.Markaid);
            
            CreateTable(
                "dbo.Markas",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        name = c.String(),
                        Modelid = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.Models",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        name = c.String(),
                        Marka_id = c.Int(),
                    })
                .PrimaryKey(t => t.id)
                .ForeignKey("dbo.Markas", t => t.Marka_id)
                .Index(t => t.Marka_id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Cars", "Markaid", "dbo.Markas");
            DropForeignKey("dbo.Models", "Marka_id", "dbo.Markas");
            DropIndex("dbo.Models", new[] { "Marka_id" });
            DropIndex("dbo.Cars", new[] { "Markaid" });
            DropTable("dbo.Models");
            DropTable("dbo.Markas");
            DropTable("dbo.Cars");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using carrent.Models;

namespace carrent.Controllers
{
    [Authorize]
    public class CarsController : Controller
    {
        private Model1 db = new Model1();

        public JsonResult models(int? id)
        {
            var models = db.Model.Where(w => w.Markaid == id).ToList();
            return Json(models, JsonRequestBehavior.AllowGet);
        }
        // GET: Cars
        public ActionResult Index()
        {
           
            var cars = db.Cars.Include(c => c.model);
            return View(cars.ToList());
        }

        // GET: Cars/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.Cars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            return View(car);
        }

        // GET: Cars/Create
        public ActionResult Create()
        {
            ViewBag.Markaid = new SelectList(db.Marka, "id", "name");
            return View();
        }

        // POST: Cars/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,year,price,color,distance,modelid")] Car car, HttpPostedFileBase productImage)
        {
            if (ModelState.IsValid)
            {
                //check if that type of a car already exists 
                var find = db.Cars.FirstOrDefault(f => f.modelid == car.modelid && f.year == car.year);
                if (find == null)
                {
                    if (productImage != null)
                    {
                        string nameImage = productImage.FileName;
                        string newName = Guid.NewGuid().ToString() + nameImage;
                        productImage.SaveAs(Server.MapPath("~/Images/" + newName));
                        car.imgUrl = newName;
                    }

                    db.Cars.Add(car);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                
            }

            ViewBag.Markaid = new SelectList(db.Marka, "id", "name");
            return View(car);
        }

        // GET: Cars/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.Cars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            ViewBag.Markaid = new SelectList(db.Marka, "id", "name");
            return View(car);
        }

        // POST: Cars/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,year,price,color,distance,modelid")] Car car, string oldImage, HttpPostedFileBase productImage)
        {
            if (ModelState.IsValid)
            {
                db.Entry(car).State = EntityState.Modified;
                if (productImage != null)
                {
                    string nameImage = productImage.FileName;
                    string newName = Guid.NewGuid().ToString() + nameImage;
                    productImage.SaveAs(Server.MapPath("~/Images/" + newName));
                    car.imgUrl = newName;

                    System.IO.File.Delete(Server.MapPath("~/Images/" + oldImage));
                }
                else
                {
                    car.imgUrl = oldImage;
                }

                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Markaid = new SelectList(db.Marka, "id", "name");
            return View(car);
        }

        // GET: Cars/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.Cars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            return View(car);
        }

        // POST: Cars/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Car car = db.Cars.Find(id);
            System.IO.File.Delete(Server.MapPath("~/Images/" + car.imgUrl));
            db.Cars.Remove(car);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

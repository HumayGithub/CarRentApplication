﻿using carrent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace carrent.Controllers
{
    public class MainController : Controller
    {
        Model1 db = new Model1();
        // GET: Main
        public ActionResult HomePage()
        {
            var cars = db.Cars.ToList();
            List<MainPageCarModel> mainmodel = new List<MainPageCarModel>();
            foreach(var a in cars)
            {
                MainPageCarModel car = new MainPageCarModel();
                car.car = a;
                car.marka = db.Model.FirstOrDefault(f => f.id == a.modelid).marka.name;
                mainmodel.Add(car);
                 
            }

            return View(mainmodel);
        }
    }
}
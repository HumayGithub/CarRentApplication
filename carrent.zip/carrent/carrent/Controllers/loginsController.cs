﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using carrent.help;
using carrent.Models;

namespace carrent.Controllers
{
    [CstAuthorize]
    public class loginsController : Controller
    {
        private Model1 db = new Model1();

        // GET: logins
        public ActionResult Index()
        {
            return View(db.Users.ToList());
        }

        // GET: logins/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            login login = db.Users.Find(id);
            if (login == null)
            {
                return HttpNotFound();
            }
            return View(login);
        }

        // GET: logins/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: logins/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,name,lastname,email,username")] login user, string Password)
        {
            if (ModelState.IsValid)
            {
                var isUserExist = db.Users.SingleOrDefault(s => s.name == user.name);
                if (isUserExist != null)
                {
                    ModelState.AddModelError("username", "user with this username  already exists");
                    return View(user);
                }

                var hashps = hash.hash1(Password);


                user.passhash = hashps;
                db.Users.Add(user);
                db.SaveChanges();



                return RedirectToAction("Index");
            }


            return View(user);
        }

        // GET: logins/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            login login = db.Users.Find(id);
            if (login == null)
            {
                return HttpNotFound();
            }
            return View(login);
        }

        // POST: logins/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,name,lastname,email,username")] login user, string Password)
        {

            if (ModelState.IsValid)
            {

                user.passhash = hash.hash1(Password);
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();







                return RedirectToAction("Index");
            }

            return View(user);
        }

        // GET: logins/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            login login = db.Users.Find(id);
            if (login == null)
            {
                return HttpNotFound();
            }
            return View(login);
        }

        // POST: logins/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            login login = db.Users.Find(id);
            db.Users.Remove(login);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

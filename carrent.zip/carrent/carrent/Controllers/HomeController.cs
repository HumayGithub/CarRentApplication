﻿using carrent.help;
using carrent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace carrent.Controllers
{
    public class HomeController : Controller
    {
        public Model1 db = new Model1();
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login([Bind(Include = "name")]login user,string password)
        {

            var phash = hash.hash1(password);
            var found = db.Users.FirstOrDefault(f => f.name.ToLower() == user.name.ToLower() && f.passhash == phash);
            if (found == null)
            {

                return View(found);
            }
            Session["userid"] = found.id;
            Session["auth"] = "true";
            return RedirectToAction("HomePage","Main");
        }

        public ActionResult Sign()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Sign(login user,string password)
        {
            if (ModelState.IsValid)
            {
                var isUserExist = db.Users.SingleOrDefault(s => s.name == user.name);
                if (isUserExist != null)
                {
                    ModelState.AddModelError("username", "user with this username  already exists");
                    return View(user);
                }
                var hashps = hash.hash1(password);
                user.passhash = hashps;
                user.isadmin = false;
                db.Users.Add(user);
                db.SaveChanges();

                return RedirectToAction("Login");
            }
            return View(user);
        }
        public ActionResult Logout()
        {
            Session["auth"] = null;
            Session["userid"] = null;
            return RedirectToAction("HomePage", "Main");
        }

    }
}